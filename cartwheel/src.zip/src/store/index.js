import Vue from 'vue'
import Vuex from 'Vuex'
// 2.全局注册
Vue.use(Vuex)
// 3.创建数据仓库Store
const store=new Vuex.Store({
    
})
// 4、对外输出
export default store