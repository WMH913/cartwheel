<template>
    <div>
        大家的5
    </div>
</template>